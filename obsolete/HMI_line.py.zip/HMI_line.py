import matplotlib.pyplot as plt
from matplotlib import animation
import random

fps = 24
total_seconds = 85
total_frames = 85 * 24
# Set the figure size
plt.rcParams['figure.figsize'] = (8, 6)

# Initialize the plot
fig, ax = plt.subplots()
line, = ax.plot([], [], lw=2)  # Initialize an empty line

# Set plot limits and labels
ax.set_xlim(0, total_frames) # 85 seconds in total
ax.set_ylim(0, 100)
ax.set_xlabel('Time (s)')
ax.set_ylabel('Autonomous Driving Confidence')

tick_interval = 5  # Interval of 5 seconds
ax.set_xticks([i * fps for i in range(0, total_seconds + 1, tick_interval)])  # Set ticks at every 5 seconds
ax.set_xticklabels([str(i) for i in range(0, total_seconds + 1, tick_interval)])  # Label ticks with every 5 seconds

confidence_values = [100]  # Confidence default starts at 100

# Calculate the confidence value
def calculate_confidence(frame, previous_value):
    time = frame / fps  # Divide by FPS to calculate time
    
    # Generate a random offset
    offset = random.uniform(-2, 2)
    new_value = previous_value + offset
    
    if time < 60:
        new_value = max(85, min(new_value, 100))
    else:
        new_value = max(60, min(new_value, 85))
    return new_value

# Update the line at each frame
def update(frame):
    if frame == len(confidence_values):
        # Calculate new value based on the last value in the list
        new_value = calculate_confidence(frame, confidence_values[-1])
        confidence_values.append(new_value)

    # Update the line data
    line.set_data(range(frame+1), confidence_values[:frame+1])

    return line,

# Create the animation
anim = animation.FuncAnimation(fig, update, frames=total_frames)

# Save the animation as a GIF
Writer = animation.PillowWriter(fps)  # 1 frame per second for 85 seconds
anim.save("line_graph.gif", writer=Writer)

plt.show()